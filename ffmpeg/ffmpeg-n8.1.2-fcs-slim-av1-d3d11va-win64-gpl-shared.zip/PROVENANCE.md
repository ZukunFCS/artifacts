# FCS slim FFmpeg SDK provenance

- Profile: `fcs-slim-av1-d3d11va`
- Target: Windows x86-64 shared libraries
- FFmpeg: `n8.1.2` (`1c2c67c0b9f7f66ab32c19dcf7f227bcd290aa4c`)
- Build host: `zukun-training-pc-2`, Docker
- Build image: `ghcr.io/btbn/ffmpeg-builds/win64-gpl-shared@sha256:c3dcdc60d35d179aad507ade1b78a5fbc3118577fd7f715c6da478764c3b7f78`
- BtbN FFmpeg-Builds recipe pin: `2437e7b868da3c11872367b15f3c613b87c24819`
- License: GPL version 3 or later
- Source: <https://github.com/FFmpeg/FFmpeg/tree/n8.1.2>

The build uses a component allowlist for FCS video reading, local media import,
audio and JPEG extraction, H.265 encoding, AV1 encoding/decoding, and D3D11VA
hardware decoding for H.264, HEVC, VP9, and AV1. Network, capture-device,
subtitle, and optical-media components are disabled.
