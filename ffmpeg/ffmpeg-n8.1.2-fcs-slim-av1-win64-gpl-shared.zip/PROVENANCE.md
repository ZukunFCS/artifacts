# FCS slim FFmpeg SDK provenance

- Profile: `fcs-slim-av1`
- Target: Windows x86-64 shared libraries
- FFmpeg: `n8.1.2`
- Build image: `ghcr.io/btbn/ffmpeg-builds/win64-gpl-shared@sha256:7d454a69878ba75c1277a35f95d724b5ed35a146f2e911b3a4592a3f24d7b464`
- x265: `4.2`
- SVT-AV1: `4.1.0`
- dav1d: `1.5.4`
- License: GPL version 3 or later
- Source: <https://github.com/FFmpeg/FFmpeg/tree/n8.1.2>

The build uses a component allowlist for FCS video reading, local media import,
audio and JPEG extraction, H.265 encoding, and AV1 encoding/decoding. Network,
capture-device, subtitle, optical-media, and hardware-acceleration components
are disabled.
